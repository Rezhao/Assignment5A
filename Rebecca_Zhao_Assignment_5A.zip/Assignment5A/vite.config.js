//vite.config.js
export default {
    //config options
    base: "/Assignment5A/",
    build: {
        chunkSizeWarningLimit: 1600,
    },
};